import { Component } from '@angular/core';

@Component({
  selector: 'app-survey-two-page',
  templateUrl: './survey-two-page.component.html',
  styleUrls: ['./survey-two-page.component.css']
})
export class SurveyTwoPageComponent {

}
