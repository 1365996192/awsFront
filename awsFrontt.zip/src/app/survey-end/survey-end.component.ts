import { Component } from '@angular/core';

@Component({
  selector: 'app-survey-end',
  templateUrl: './survey-end.component.html',
  styleUrls: ['./survey-end.component.css']
})
export class SurveyEndComponent {

}
