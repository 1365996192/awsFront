import { Component } from '@angular/core';

@Component({
  selector: 'app-dashboard-news',
  templateUrl: './dashboard-news.component.html',
  styleUrls: ['./dashboard-news.component.css']
})
export class DashboardNewsComponent {

}
