import { Component } from '@angular/core';

@Component({
  selector: 'app-dashboard-me',
  templateUrl: './dashboard-me.component.html',
  styleUrls: ['./dashboard-me.component.css']
})
export class DashboardMeComponent {

}
