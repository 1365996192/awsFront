import { Component } from '@angular/core';

@Component({
  selector: 'app-survey-three-page',
  templateUrl: './survey-three-page.component.html',
  styleUrls: ['./survey-three-page.component.css']
})
export class SurveyThreePageComponent {

}
