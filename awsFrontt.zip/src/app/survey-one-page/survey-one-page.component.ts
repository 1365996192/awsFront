import { Component } from '@angular/core';

@Component({
  selector: 'app-survey-one-page',
  templateUrl: './survey-one-page.component.html',
  styleUrls: ['./survey-one-page.component.css']
})
export class SurveyOnePageComponent {

}
