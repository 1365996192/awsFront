import { Component } from '@angular/core';

@Component({
  selector: 'app-begin-page',
  templateUrl: './begin-page.component.html',
  styleUrls: ['./begin-page.component.css']
})
export class BeginPageComponent {

}
